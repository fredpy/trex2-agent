#ifndef H_AUV_factors
# define H_AUV_factors

# define CH_fact 1e-4
# define BB_fact 1e-3

#endif // H_AUV_factors
