#define SVN_INFO 1
#define SVN_ROOT "branches/trex_0_5_x"
#define SVN_REV "2018S"
